# IJYE — The Engineering Record (website redesign draft)

A static redesign concept for the International Journal of Youth Engineering, using the existing repository's IJYE identity and publication concepts.

## Contents

- `index.html` — redesigned homepage
- `Journal/index.html` — journal archive landing page with software and hardware engineering categories
- `assets/styles.css` — shared theme, responsive layout, typography, colors, components
- `assets/ijye-robotic-claw-blueprint.png` — cropped robotic arm/claw illustration extracted from the earlier IJYE reference mockup
- `assets/app.js` — accessible mobile navigation toggle

## Run locally

No build system or package installation is required. Open `index.html` in a browser. For best testing, serve the folder over HTTP:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## GitHub Pages

The files are arranged for a repository root deployment. Upload the contents of this folder to a test branch or separate repository. The `Journal/` and `assets/` links use relative paths so they work under a project-site URL as well.

## Submission pathways\n\nThe homepage presents four intended routes: Hack Club / Software Engineering, Hack Club / Hardware Engineering, SOTI / Software Engineering, and SOTI / Hardware Engineering. These labels are not a claim of endorsement or formal affiliation. Confirm authorization, eligibility, and the actual submission workflow with each organization before launch.\n\n## Design system

- Midnight navy: `#071827`
- Signal blue: `#168BFA`
- Safety orange: `#FF792B`
- Circuit teal: `#0E897C`
- Drawing white: `#F2F5F7`
- Display type: Space Grotesk
- Body type: Inter
- Technical labels: IBM Plex Mono

The robotic arm hero illustration is inline SVG, so it does not require an external image asset.

## Before launch

- Verify that `submissions@ijye.org` is active.
- Confirm current submission eligibility and nomination policy.
- Replace the empty archive states with approved article metadata only when articles are ready to publish.
- Add detailed peer-review, ethics, privacy, copyright, corrections, and author guidelines that accurately reflect IJYE's actual processes.
- Test all links and mobile behavior on the final hosting setup.

This is a design prototype, not a claim that articles have been published or peer reviewed.
